//= require ../bower_components/js-url/url.min.js
//= require ../bower_components/js-cookie/src/js.cookie.js
//= require ../bower_components/jquery.debug/dist/jquery.debug.min.js
//= require ../bower_components/jquery-validation/dist/jquery.validate.min.js
//= require ../bower_components/flexslider/jquery.flexslider-min.js
